import aiosqlite

DATABASE_PATH = "database/rpg.db"

async def migrate():
    """Ensure all required tables exist in the database."""
    
    # Connect to the database (creates file if it doesn't exist)
    async with aiosqlite.connect(DATABASE_PATH) as db:

        # Stores player stats, level, currency, and last daily claim
        await db.execute("""
        CREATE TABLE IF NOT EXISTS players (
            user_id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            class TEXT NOT NULL,
            level INTEGER DEFAULT 1,
            xp INTEGER DEFAULT 0,
            hp INTEGER DEFAULT 30,
            attack INTEGER DEFAULT 5,
            defense INTEGER DEFAULT 3,
            gold INTEGER DEFAULT 100,
            gems INTEGER DEFAULT 5,
            last_daily TEXT
        )
        """)

        # Stores player items and quantities
        await db.execute("""
        CREATE TABLE IF NOT EXISTS inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            item_name TEXT NOT NULL,
            quantity INTEGER DEFAULT 1,
            rarity TEXT DEFAULT 'common',
            FOREIGN KEY (user_id) REFERENCES players(user_id)
        )
        """)

        # Stores items listed for sale by players
        await db.execute("""
        CREATE TABLE IF NOT EXISTS market (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            seller_id INTEGER NOT NULL,
            item_name TEXT NOT NULL,
            quantity INTEGER NOT NULL,
            price INTEGER NOT NULL
        )
        """)

        # Stores player pets and their bonuses
        await db.execute("""
        CREATE TABLE IF NOT EXISTS pets (
            user_id INTEGER PRIMARY KEY,
            pet_name TEXT NOT NULL,
            level INTEGER NOT NULL,
            xp INTEGER NOT NULL,
            hp_bonus INTEGER DEFAULT 0,
            attack_bonus INTEGER DEFAULT 0,
            defense_bonus INTEGER DEFAULT 0
        )
        """)

        # Stores player quests, progress, goals, and rewards
        await db.execute("""
        CREATE TABLE IF NOT EXISTS quests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            quest_name TEXT NOT NULL,
            progress INTEGER DEFAULT 0,
            goal INTEGER NOT NULL,
            reward_xp INTEGER DEFAULT 0,
            reward_gold INTEGER DEFAULT 0,
            reward_item TEXT,
            completed INTEGER DEFAULT 0
        )
        """)

        # Commit all changes
        await db.commit()
        print("✅ Database migration complete")



import random

# Level Up System
def xp_required_for_next_level(level: int) -> int:
    # Hybrid formula (Option 3: Flat + Exponential)
    return int(level * 50 + (level ** 2.2))

async def check_level_up(user_id: int):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        cursor = await db.execute(
            "SELECT level, xp, hp, attack, defense FROM players WHERE user_id = ?",
            (user_id,)
        )
        row = await cursor.fetchone()
        if not row:
            return None

        level, xp, hp, attack, defense = row
        leveled_up = False
        new_stats = {}

        while xp >= xp_required_for_next_level(level):
            xp -= xp_required_for_next_level(level)
            level += 1
            leveled_up = True

            # Stat growth
            hp += random.randint(2,5)
            attack += 1
            defense += 1

        if leveled_up:
            await db.execute(
                "UPDATE players SET level = ?, xp = ?, hp = ?, attack = ?, defense = ? WHERE user_id = ?",
                (level, xp, hp, attack, defense, user_id)
            )
            await db.commit()
            new_stats = {"level": level, "hp": hp, "attack": attack, "defense": defense}

        return new_stats if leveled_up else None
