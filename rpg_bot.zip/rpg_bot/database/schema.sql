-- player
CREATE TABLE IF NOT EXISTS players (
    user_id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    class TEXT NOT NULL,
    level INTEGER DEFAULT 1,
    xp INTEGER DEFAULT 0,
    hp INTEGER DEFAULT 30,
    attack INTEGER DEFAULT 5,
    defense INTEGER DEFAULT 3,
    gold INTEGER DEFAULT 100,
    gems INTEGER DEFAULT 5,
    last_daily TEXT DEFAULT NULL,
    equipped INTEGER DEFAULT 0
);

-- Stores player equipment
CREATE TABLE IF NOT EXISTS equipment (
    user_id INTEGER PRIMARY KEY,
    weapon_name TEXT DEFAULT NULL,
    weapon_attack INTEGER DEFAULT 0,
    armor_name TEXT DEFAULT NULL,
    armor_defense INTEGER DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES players(user_id)
);

-- Inventory table
CREATE TABLE IF NOT EXISTS inventory (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    item_name TEXT NOT NULL,
    quantity INTEGER DEFAULT 1,
    rarity TEXT DEFAULT 'common',
    FOREIGN KEY (user_id) REFERENCES players(user_id)
);

-- market
CREATE TABLE IF NOT EXISTS market (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    seller_id INTEGER NOT NULL,
    item_name TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    price INTEGER NOT NULL
);

-- pet
CREATE TABLE IF NOT EXISTS pets (
    user_id INTEGER PRIMARY KEY,
    pet_name TEXT NOT NULL,
    level INTEGER NOT NULL,
    xp INTEGER NOT NULL,
    hp_bonus INTEGER DEFAULT 0,
    attack_bonus INTEGER DEFAULT 0,
    defense_bonus INTEGER DEFAULT 0
);

-- quest
CREATE TABLE IF NOT EXISTS quests (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    quest_name TEXT NOT NULL,
    progress INTEGER DEFAULT 0,
    goal INTEGER NOT NULL,
    reward_xp INTEGER DEFAULT 0,
    reward_gold INTEGER DEFAULT 0,
    reward_item TEXT,
    completed INTEGER DEFAULT 0,
    monster_name TEXT NOT NULL
);
