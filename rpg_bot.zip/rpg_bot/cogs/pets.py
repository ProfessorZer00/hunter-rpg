import asyncio
import discord
from discord.ext import commands
import aiosqlite
from config import DATABASE_PATH
import random

PETS = {
    # Tier 1 – Common Pets
    "slime": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "common", "chance": 50},
    "rat": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "common", "chance": 50},
    "rabbit": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "common", "chance": 50},
    "wolf": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "common", "chance": 50},
    "cat": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "common", "chance": 50},
    "dog": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "common", "chance": 50},
    "sparrow": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "common", "chance": 50},
    "turtle": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "common", "chance": 50},

    # Tier 2 – Uncommon Pets
    "hawk": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "uncommon", "chance": 20},
    "boar": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "uncommon", "chance": 20},
    "fox": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "uncommon", "chance": 20},
    "owl": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "uncommon", "chance": 20},
    "snake": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "uncommon", "chance": 20},
    "bat": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "uncommon", "chance": 20},
    "goat": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "uncommon", "chance": 20},
    "monkey": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "uncommon", "chance": 20},

    # Tier 3 – Rare Pets
    "bear": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "rare", "chance": 10},
    "stag": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "rare", "chance": 10},
    "lion": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "rare", "chance": 10},
    "tiger": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "rare", "chance": 10},
    "panther": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "rare", "chance": 10},
    "eagle": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "rare", "chance": 10},
    "rhino": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "rare", "chance": 10},
    "crocodile": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "rare", "chance": 10},

    # Tier 4 – Epic Pets
    "phoenix": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "epic", "chance": 8},
    "griffin": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "epic", "chance": 8},
    "unicorn": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "epic", "chance": 8},
    "chimera": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "epic", "chance": 8},
    "basilisk": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "epic", "chance": 8},
    "wyvern": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "epic", "chance": 8},
    "pegasus": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "epic", "chance": 8},
    "golem": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "epic", "chance": 8},

    # Tier 5 – Legendary Pets
    "dragonling": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "legendary", "chance": 2},
    "hydra": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "legendary", "chance": 2},
    "leviathan": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "legendary", "chance": 2},
    "cerberus": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "legendary", "chance": 2},
    "kraken": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "legendary", "chance": 2},
    "fairy": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "legendary", "chance": 2},
    "spirit_fox": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "legendary", "chance": 2},
    "shadow_wolf": {"attack": 2, "defense": 1, "hp": random.randint(5, 10), "rarity": "legendary", "chance": 2},
}


def get_random_pet():
    all_pets = list(PETS.items())
    weighted = [pet for pet, data in all_pets for _ in range(data["chance"])]
    chosen = random.choice(weighted)
    return chosen, PETS[chosen]


class Pets(commands.Cog):
    """RPG Pets Cog - Adoption, training, and management of pets."""

    def __init__(self, bot):
        self.bot = bot

    async def pet_exists(self, user_id: int) -> bool:
        async with aiosqlite.connect(DATABASE_PATH) as db:
            cursor = await db.execute("SELECT 1 FROM pets WHERE user_id = ?", (user_id,))
            return await cursor.fetchone() is not None

    # Adoption & Release
    @commands.command(name="adoptpet", aliases=["ap"])
    async def get_random_pet_command(self, ctx):
        """Get a random pet (based on rarity chance)."""
        if await self.pet_exists(ctx.author.id):
            embed = discord.Embed(
                title="⚠️ Already Have a Pet",
                description="You already have a pet. Release it first with `!releasepet`.",
                color=discord.Color.orange()
            )
            await ctx.send(embed=embed)
            return

        pet_name, stats = get_random_pet()

        async with aiosqlite.connect(DATABASE_PATH) as db:
            await db.execute(
                """
                INSERT INTO pets (user_id, pet_name, level, xp, hp_bonus, attack_bonus, defense_bonus)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (ctx.author.id, pet_name, 1, 0, stats.get("hp", 0), stats.get("attack", 0), stats.get("defense", 0)),
            )
            await db.commit()

        rarity_colors = {
            "common": discord.Color.light_grey(),
            "uncommon": discord.Color.green(),
            "rare": discord.Color.blue(),
            "epic": discord.Color.purple(),
            "legendary": discord.Color.gold()
        }

        embed = discord.Embed(
            title="🎉 You Got a Pet!",
            description=f"{ctx.author.mention} obtained a **{pet_name.capitalize()}** 🐾",
            color=rarity_colors.get(stats["rarity"], discord.Color.teal())
        )
        embed.add_field(name="Rarity", value=stats['rarity'].capitalize())
        embed.add_field(name="❤️ HP", value=stats['hp'])
        embed.add_field(name="⚔️ Attack", value=stats['attack'])
        embed.add_field(name="🛡️ Defense", value=stats['defense'])

        await ctx.send(embed=embed)

    @commands.command(name="releasepet", aliases=["rp"])
    async def release_pet(self, ctx):
        """Release your current pet."""
        async with aiosqlite.connect(DATABASE_PATH) as db:
            await db.execute("DELETE FROM pets WHERE user_id = ?", (ctx.author.id,))
            await db.commit()

        embed = discord.Embed(
            title="💔 Pet Released",
            description=f"{ctx.author.mention}, you released your pet.",
            color=discord.Color.red()
        )
        await ctx.send(embed=embed)

    # Pet List (Pagination)
    @commands.command(name="petlist", aliases=["pl"])
    async def list_pets(self, ctx):
        """Show all available pets with pagination (10 per page)."""
        pets_per_page = 10
        pet_items = list(PETS.items())
        total_pages = (len(pet_items) - 1) // pets_per_page + 1

        class PetListView(discord.ui.View):
            def __init__(self, page=0):
                super().__init__(timeout=60)
                self.page = page

            async def update_embed(self, interaction=None):
                start = self.page * pets_per_page
                end = start + pets_per_page
                embed = discord.Embed(
                    title=f"🐾 Available Pets (Page {self.page+1}/{total_pages})",
                    color=discord.Color.purple()
                )
                for pet, stats in pet_items[start:end]:
                    desc = f"❤️ HP+{stats.get('hp',0)} | ⚔️ ATK+{stats.get('attack',0)} | 🛡️ DEF+{stats.get('defense',0)}"
                    embed.add_field(name=pet.capitalize(), value=desc, inline=False)

                if interaction:
                    await interaction.response.edit_message(embed=embed, view=self)
                else:
                    await ctx.send(embed=embed, view=self)

            @discord.ui.button(label="⬅️ Prev", style=discord.ButtonStyle.gray)
            async def prev_page(self, interaction, button):
                if interaction.user.id != ctx.author.id:
                    return await interaction.response.send_message("Not your menu!", ephemeral=True)
                if self.page > 0:
                    self.page -= 1
                    await self.update_embed(interaction)

            @discord.ui.button(label="➡️ Next", style=discord.ButtonStyle.gray)
            async def next_page(self, interaction, button):
                if interaction.user.id != ctx.author.id:
                    return await interaction.response.send_message("Not your menu!", ephemeral=True)
                if self.page < total_pages - 1:
                    self.page += 1
                    await self.update_embed(interaction)

        view = PetListView()
        await view.update_embed()

    # Pet Info
    @commands.command(name="mypet", aliases=["pet"])
    async def my_pet(self, ctx):
        """Show your current pet."""
        async with aiosqlite.connect(DATABASE_PATH) as db:
            cursor = await db.execute(
                "SELECT pet_name, level, xp, hp_bonus, attack_bonus, defense_bonus FROM pets WHERE user_id = ?",
                (ctx.author.id,),
            )
            pet = await cursor.fetchone()

        if not pet:
            embed = discord.Embed(
                title="⚠️ No Pet Found",
                description="You don't have a pet. Adopt one with `!adoptpet`.",
                color=discord.Color.orange()
            )
            await ctx.send(embed=embed)
            return

        pet_name, level, xp, hp, attack, defense = pet
        embed = discord.Embed(
            title=f"🐕 {ctx.author.name}'s Pet",
            color=discord.Color.blue()
        )
        embed.add_field(name="📛 Name", value=pet_name.capitalize())
        embed.add_field(name="⬆️ Level", value=level)
        embed.add_field(name="⭐ XP", value=f"{xp}/100")
        embed.add_field(name="❤️ HP Bonus", value=hp)
        embed.add_field(name="⚔️ Attack Bonus", value=attack)
        embed.add_field(name="🛡️ Defense Bonus", value=defense)

        await ctx.send(embed=embed)

    # Training, Spin, etc. (unchanged)
    # ... keep your trainpet, petspin code here as-is ...


# Cog Setup
async def setup(bot):
    """Setup function to load the Pets cog."""
    await bot.add_cog(Pets(bot))
