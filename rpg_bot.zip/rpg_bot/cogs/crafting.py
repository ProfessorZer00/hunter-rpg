import discord
from discord.ext import commands
from discord import ui
import aiosqlite
from config import DATABASE_PATH

# Example recipes
RECIPES = {
    "iron sword": {
        "name": "Iron Sword",
        "materials": {"iron_ingot": 3, "wood": 1},
        "xp": 20
    },
    "health potion": {
        "name": "Health Potion",
        "materials": {"herb": 2, "water": 1},
        "xp": 10
    },
}

class Crafting(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def has_materials(self, user_id: int, materials: dict):
        """Check if player has enough materials in inventory"""
        async with aiosqlite.connect(DATABASE_PATH) as db:
            for item, amount in materials.items():
                async with db.execute(
                    "SELECT quantity FROM inventory WHERE user_id = ? AND item_name = ?",
                    (user_id, item)
                ) as cursor:
                    result = await cursor.fetchone()
                    if not result or result[0] < amount:
                        return False
        return True

    async def remove_materials(self, user_id: int, materials: dict):
        """Remove used materials from inventory (only if enough exist)"""
        async with aiosqlite.connect(DATABASE_PATH) as db:
            for item, amount in materials.items():
                await db.execute(
                    "UPDATE inventory SET quantity = quantity - ? "
                    "WHERE user_id = ? AND item_name = ? AND quantity >= ?",
                    (amount, user_id, item, amount)
                )
            await db.commit()

    async def add_item(self, user_id: int, item_name: str, quantity: int = 1):
        """Add crafted item to inventory"""
        async with aiosqlite.connect(DATABASE_PATH) as db:
            await db.execute(
                "INSERT INTO inventory(user_id, item_name, quantity) VALUES (?, ?, ?) "
                "ON CONFLICT(user_id, item_name) DO UPDATE SET quantity = quantity + ?",
                (user_id, item_name, quantity, quantity)
            )
            await db.commit()

    async def add_xp(self, user_id: int, xp: int):
        """Add XP to player after crafting"""
        async with aiosqlite.connect(DATABASE_PATH) as db:
            await db.execute(
                "UPDATE players SET xp = xp + ? WHERE user_id = ?",
                (xp, user_id)
            )
            await db.commit()

    @commands.command(name="craft")
    async def craft(self, ctx, *, recipe_name: str):
        """Craft an item using a recipe"""
        recipe = RECIPES.get(recipe_name.lower())
        if not recipe:
            await ctx.send("❌ That recipe does not exist. Try: " + ", ".join(RECIPES.keys()))
            return

        if not await self.has_materials(ctx.author.id, recipe["materials"]):
            await ctx.send("⚠️ You don't have enough materials to craft this item.")
            return

        # Confirmation button
        class ConfirmCraft(ui.View):
            def __init__(self):
                super().__init__(timeout=30)
                self.confirmed = False

            @ui.button(label="Craft", style=discord.ButtonStyle.green)
            async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
                if interaction.user.id != ctx.author.id:
                    await interaction.response.send_message("This is not your crafting session!", ephemeral=True)
                    return
                self.confirmed = True
                self.stop()
                await interaction.response.send_message(f"Crafting {recipe['name']}...", ephemeral=True)

            @ui.button(label="Cancel", style=discord.ButtonStyle.red)
            async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
                if interaction.user.id != ctx.author.id:
                    await interaction.response.send_message("This is not your crafting session!", ephemeral=True)
                    return
                self.stop()
                await interaction.response.send_message("Crafting cancelled.", ephemeral=True)

        view = ConfirmCraft()
        await ctx.send(f"🛠️ Do you want to craft **{recipe['name']}**?", view=view)
        await view.wait()

        if view.confirmed:
            await self.remove_materials(ctx.author.id, recipe["materials"])
            await self.add_item(ctx.author.id, recipe["name"])
            await self.add_xp(ctx.author.id, recipe["xp"])
            await ctx.send(f"✅ You successfully crafted **{recipe['name']}**! You gained {recipe['xp']} XP.")

async def setup(bot):
    await bot.add_cog(Crafting(bot))
