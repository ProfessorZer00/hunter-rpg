import discord
from discord.ext import commands
import aiosqlite
import random
import asyncio
import time
from config import DATABASE_PATH

class Raid(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.active_raids = {}  # guild_id: raid data
        self.raid_cooldowns = {}  # starter cooldowns
        self.max_players = 5
        self.attack_cooldown = 10
        self.raid_global_cooldown = 2*60*60  # 2 hours
        self.raid_duration = 5*60

    async def create_raid(self):
        bosses = [
        ("Ancient Dragon", 1200, 500, 300, "Dragon Scale"),
        ("Shadow Demon", 900, 400, 250, "Demon Fang"),
        ("Titan Golem", 1500, 600, 400, "Golem Core"),
        ("Inferno Phoenix", 1000, 450, 300, "Phoenix Feather"),
        ("Kraken", 1300, 550, 350, "Kraken Tentacle"),
        ("Lich King", 1100, 480, 320, "Soul Crystal"),
        ("Dark Hydra", 1400, 600, 400, "Hydra Fang"),
        ("Dread Warlord", 950, 420, 280, "Warlord's Sword"),
        ("Volcanic Behemoth", 1600, 650, 450, "Molten Core"),
        ("Frost Giant", 1250, 500, 300, "Frozen Heart"),
        ("Necro Dragon", 1350, 580, 380, "Necrotic Scale"),
        ("Storm Serpent", 1000, 450, 300, "Thunder Fang"),
        ("Void Reaper", 1200, 500, 320, "Reaper Scythe"),
        ("Titanus Rex", 1700, 700, 500, "Titan Bone"),
        ("Cursed Paladin", 1100, 480, 320, "Paladin's Shield"),
        ("Blood Warlock", 950, 400, 280, "Blood Tome"),
        ("Sand Wyrm", 1050, 430, 290, "Wyrm Tooth"),
        ("Crystal Colossus", 1400, 600, 400, "Crystal Fragment"),
        ("Abyssal Kraken", 1500, 650, 420, "Abyssal Tentacle"),
        ("Eternal Vampire", 1200, 500, 350, "Vampire Fang"),
    ]
        return random.choice(bosses)

    def generate_hp_bar(self, current, maximum, length=20):
        filled = max(0, int(length * current / maximum))
        empty = length - filled
        return "🟥" * filled + "⬛" * empty

    def generate_slot_status(self, raid):
        slots = []
        for i in range(self.max_players):
            uid = raid.get(f"slot_{i}")
            if i == 0:
                slots.append(f"👑 {self.bot.get_user(uid).display_name if uid else 'Starter'}")
            else:
                slots.append(self.bot.get_user(uid).display_name if uid else "Empty")
        return "\n".join(slots)

    async def update_raid_embed(self, guild_id):
        raid = self.active_raids[guild_id]
        embed = discord.Embed(
            title=f"⚔️ Raid Boss: {raid['boss']}",
            description=f"HP: {max(0, raid['hp'])}/{raid['max_hp']}\n{self.generate_hp_bar(raid['hp'], raid['max_hp'])}",
            color=discord.Color.orange()
        )
        embed.add_field(name="Raid Slots", value=self.generate_slot_status(raid), inline=False)
        await raid["message"].edit(embed=embed, view=raid["view"])

    @commands.command(name="raid")
    async def raid(self, ctx):
        user_id = ctx.author.id
        now = time.time()
        if user_id in self.raid_cooldowns and now - self.raid_cooldowns[user_id] < self.raid_global_cooldown:
            remaining = int(self.raid_global_cooldown - (now - self.raid_cooldowns[user_id]))
            h, m, s = remaining//3600, (remaining%3600)//60, remaining%60
            await ctx.send(f"❌ You recently started a raid. Try again in {h}h {m}m {s}s.")
            return

        guild_id = ctx.guild.id
        if guild_id in self.active_raids:
            await self.update_raid_embed(guild_id)
            return

        boss_name, hp, reward_xp, reward_gold, reward_item = await self.create_raid()
        embed = discord.Embed(
            title=f"🔥 A wild **{boss_name}** has appeared!",
            description=f"HP: {hp}\n{self.generate_hp_bar(hp,hp)}",
            color=discord.Color.red()
        )
        embed.add_field(name="Instructions", value=f"Click empty slots to join! Max {self.max_players} players.")
        embed.set_footer(text="Good luck, heroes!")

        view = RaidSlotView(self, guild_id)
        message = await ctx.send(embed=embed, view=view)

        # Starter auto join
        self.active_raids[guild_id] = {
            "boss": boss_name,
            "hp": hp,
            "max_hp": hp,
            "reward_xp": reward_xp,
            "reward_gold": reward_gold,
            "reward_item": reward_item,
            "starter": user_id,
            "slot_0": user_id,
            "slot_1": None,
            "slot_2": None,
            "slot_3": None,
            "slot_4": None,
            "players": {user_id: 0},
            "message": message,
            "cooldowns": {},
            "view": view,
            "start_time": time.time()
        }
        self.raid_cooldowns[user_id] = now
        asyncio.create_task(self.raid_timer(guild_id))

    async def raid_timer(self, guild_id):
        await asyncio.sleep(self.raid_duration)
        if guild_id in self.active_raids:
            raid = self.active_raids[guild_id]
            channel = raid["message"].channel
            await channel.send(f"⏰ Time's up! **{raid['boss']}** escaped! Partial rewards granted.")
            await self.complete_raid(channel.guild, guild_id, escaped=True)

    async def attack(self, guild_id, user):
        user_id = user.id
        raid = self.active_raids[guild_id]
        now = asyncio.get_event_loop().time()
        last = raid["cooldowns"].get(user_id, 0)
        if now - last < self.attack_cooldown:
            return False, int(self.attack_cooldown - (now-last))

        raid["cooldowns"][user_id] = now
        damage = random.randint(20,60)
        raid["hp"] -= damage
        raid["players"][user_id] += damage
        await self.update_raid_embed(guild_id)
        if raid["hp"] <= 0:
            await self.complete_raid(user.guild, guild_id)
        return True, damage

    async def complete_raid(self, guild, guild_id, escaped=False):
        raid = self.active_raids[guild_id]
        channel = raid["message"].channel
        boss = raid["boss"]
        xp = raid["reward_xp"]
        gold = raid["reward_gold"]
        item = raid["reward_item"]

        title = f"{boss} defeated!" if not escaped else f"{boss} escaped!"
        color = discord.Color.gold() if not escaped else discord.Color.dark_gray()
        await channel.send(embed=discord.Embed(title=title, color=color))

        async with aiosqlite.connect(DATABASE_PATH) as db:
            total_damage = sum(raid["players"].values())
            for user_id, dmg in raid["players"].items():
                contribution = dmg/total_damage if total_damage else 0
                await db.execute(
                    "UPDATE players SET xp = xp + ?, gold = gold + ? WHERE user_id = ?",
                    (int(xp*contribution), int(gold*contribution), user_id)
                )
                if item and not escaped and random.random()<0.2:
                    await db.execute(
                        "INSERT INTO inventory (user_id,item_name,quantity) VALUES (?,?,1) "
                        "ON CONFLICT(user_id,item_name) DO UPDATE SET quantity=quantity+1",
                        (user_id,item)
                    )
            await db.commit()
        await channel.send(embed=discord.Embed(title="🎉 Rewards Distributed!", color=discord.Color.green()))
        del self.active_raids[guild_id]

class RaidSlotView(discord.ui.View):
    def __init__(self, cog, guild_id):
        super().__init__(timeout=None)
        self.cog = cog
        self.guild_id = guild_id
        self.max_players = 5

        for i in range(5):
            label = "👑 Starter" if i==0 else "Empty"
            button = discord.ui.Button(label=label, style=discord.ButtonStyle.secondary, custom_id=f"slot_{i}")
            button.callback = self.slot_callback
            self.add_item(button)

    async def slot_callback(self, interaction: discord.Interaction):
        raid = self.cog.active_raids[self.guild_id]
        user_id = interaction.user.id
        if user_id == raid["starter"]:
            await interaction.response.send_message("👑 You are the raid starter!", ephemeral=True)
            return

        for i in range(1,self.max_players):
            if raid.get(f"slot_{i}") is None:
                raid[f"slot_{i}"] = user_id
                raid["players"][user_id] = 0
                await interaction.response.send_message(f"✅ {interaction.user.display_name} joined slot {i+1}!", ephemeral=True)
                await self.cog.update_raid_embed(self.guild_id)

                if all(raid.get(f"slot_{j}") for j in range(self.max_players)):
                    raid["view"] = RaidAttackView(self.cog, self.guild_id)
                    await raid["message"].edit(view=raid["view"])
                return
        await interaction.response.send_message("❌ Raid is full!", ephemeral=True)

class RaidAttackView(discord.ui.View):
    def __init__(self, cog, guild_id):
        super().__init__(timeout=None)
        self.cog = cog
        self.guild_id = guild_id
        attack_btn = discord.ui.Button(label="⚔️ Attack", style=discord.ButtonStyle.red)
        attack_btn.callback = self.attack_callback
        self.add_item(attack_btn)

    async def attack_callback(self, interaction: discord.Interaction):
        success, damage = await self.cog.attack(self.guild_id, interaction.user)
        raid = self.cog.active_raids[self.guild_id]
        if not success:
            await interaction.response.send_message(f"⏱️ Cooldown! Wait {damage}s.", ephemeral=True)
        else:
            embed = discord.Embed(
                title=f"⚔️ {interaction.user.display_name} attacked!",
                description=f"Dealt **{damage} damage**!\nHP: {max(0,raid['hp'])}/{raid['max_hp']}\n{self.cog.generate_hp_bar(raid['hp'], raid['max_hp'])}",
                color=discord.Color.orange()
            )
            embed.add_field(name="Raid Slots", value=self.cog.generate_slot_status(raid), inline=False)
            await interaction.response.send_message(embed=embed, ephemeral=False)

async def setup(bot):
    await bot.add_cog(Raid(bot))
