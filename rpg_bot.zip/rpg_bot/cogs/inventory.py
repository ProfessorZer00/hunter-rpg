import discord
from discord.ext import commands
import aiosqlite
from config import DATABASE_PATH
import math

class Inventory(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def player_exists(self, user_id: int):
        async with aiosqlite.connect(DATABASE_PATH) as db:
            cursor = await db.execute("SELECT 1 FROM players WHERE user_id = ?", (user_id,))
            return await cursor.fetchone() is not None

    async def add_item_to_inventory(self, user_id: int, item_name: str, quantity: int = 1, rarity: str = "common"):
        """Add a stackable item to the player's inventory"""
        async with aiosqlite.connect(DATABASE_PATH) as db:
            cursor = await db.execute(
                "SELECT quantity FROM inventory WHERE user_id = ? AND item_name = ?",
                (user_id, item_name)
            )
            row = await cursor.fetchone()
            if row:
                new_qty = row[0] + quantity
                await db.execute(
                    "UPDATE inventory SET quantity = ? WHERE user_id = ? AND item_name = ?",
                    (new_qty, user_id, item_name)
                )
            else:
                await db.execute(
                    "INSERT INTO inventory (user_id, item_name, quantity, rarity) VALUES (?, ?, ?, ?)",
                    (user_id, item_name, quantity, rarity)
                )
            await db.commit()

    @commands.command(name="inventory", aliases=["inv", "bag"])
    async def inventory(self, ctx):
        """Show player's inventory with pagination and emojis"""
        user_id = ctx.author.id

        if not await self.player_exists(user_id):
            await ctx.send(f"⚠️ {ctx.author.mention}, you must `!register` first.")
            return

        async with aiosqlite.connect(DATABASE_PATH) as db:
            cursor = await db.execute(
                "SELECT item_name, quantity, rarity FROM inventory WHERE user_id = ? ORDER BY rarity DESC, item_name ASC",
                (user_id,)
            )
            items = await cursor.fetchall()

        if not items:
            await ctx.send(f"🎒 {ctx.author.mention}, your inventory is empty.")
            return

        rarity_emoji = {
            "common": "⚪",
            "uncommon": "🟢",
            "rare": "🔵",
            "epic": "🟣",
            "legendary": "🟡"
        }

        items_per_page = 10
        total_pages = math.ceil(len(items) / items_per_page)

        # Define a button view for pagination
        class InventoryView(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=120)
                self.current_page = 0

            async def update_embed(self, interaction):
                start = self.current_page * items_per_page
                end = start + items_per_page
                page_items = items[start:end]

                embed = discord.Embed(
                    title=f"🎒 {ctx.author.name}'s Inventory",
                    description=f"Page {self.current_page + 1}/{total_pages}",
                    color=discord.Color.gold()
                )

                for item_name, quantity, rarity in page_items:
                    emoji = rarity_emoji.get(rarity.lower(), "⚪")
                    embed.add_field(
                        name=f"{emoji} {item_name} ({rarity.title()})",
                        value=f"Quantity: {quantity}",
                        inline=False
                    )

                await interaction.response.edit_message(embed=embed, view=self)

            @discord.ui.button(label="⬅️ Prev", style=discord.ButtonStyle.blurple)
            async def prev(self, interaction: discord.Interaction, button: discord.ui.Button):
                self.current_page = (self.current_page - 1) % total_pages
                await self.update_embed(interaction)

            @discord.ui.button(label="➡️ Next", style=discord.ButtonStyle.blurple)
            async def next(self, interaction: discord.Interaction, button: discord.ui.Button):
                self.current_page = (self.current_page + 1) % total_pages
                await self.update_embed(interaction)

        view = InventoryView()
        # Send first page
        start = 0
        end = items_per_page
        embed = discord.Embed(
            title=f"🎒 {ctx.author.name}'s Inventory",
            description=f"Page 1/{total_pages}",
            color=discord.Color.gold()
        )
        for item_name, quantity, rarity in items[start:end]:
            emoji = rarity_emoji.get(rarity.lower(), "⚪")
            embed.add_field(
                name=f"{emoji} {item_name} ({rarity.title()})",
                value=f"Quantity: {quantity}",
                inline=False
            )

        await ctx.send(embed=embed, view=view)

    @commands.command(name="additem")
    @commands.is_owner()
    async def add_item(self, ctx, member: discord.Member, item_name: str, quantity: int = 1, rarity: str = "common"):
        """(Admin) Give a stackable item to a player"""
        await self.add_item_to_inventory(member.id, item_name, quantity, rarity)
        await ctx.send(f"✅ Gave {quantity}x {item_name} ({rarity}) 🎁 to {member.mention}.")

async def setup(bot):
    await bot.add_cog(Inventory(bot))
