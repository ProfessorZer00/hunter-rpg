import discord
from discord.ext import commands
import aiosqlite
from config import DATABASE_PATH


class Market(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def get_balance(self, user_id: int):
        """Get player's current gold"""
        async with aiosqlite.connect(DATABASE_PATH) as db:
            cursor = await db.execute("SELECT gold FROM players WHERE user_id = ?", (user_id,))
            row = await cursor.fetchone()
        return row[0] if row else 0

    async def update_balance(self, user_id: int, gold_change: int):
        """Update player's gold balance"""
        async with aiosqlite.connect(DATABASE_PATH) as db:
            await db.execute(
                "UPDATE players SET gold = gold + ? WHERE user_id = ?",
                (gold_change, user_id),
            )
            await db.commit()

    async def update_inventory(self, user_id: int, item: str, qty: int):
        """Add or remove items from inventory"""
        async with aiosqlite.connect(DATABASE_PATH) as db:
            cursor = await db.execute(
                "SELECT quantity FROM inventory WHERE user_id = ? AND item_name = ?",
                (user_id, item),
            )
            row = await cursor.fetchone()
            if row:
                new_qty = row[0] + qty
                if new_qty <= 0:
                    await db.execute(
                        "DELETE FROM inventory WHERE user_id = ? AND item_name = ?",
                        (user_id, item),
                    )
                else:
                    await db.execute(
                        "UPDATE inventory SET quantity = ? WHERE user_id = ? AND item_name = ?",
                        (new_qty, user_id, item),
                    )
            else:
                if qty > 0:
                    await db.execute(
                        "INSERT INTO inventory (user_id, item_name, quantity) VALUES (?, ?, ?)",
                        (user_id, item, qty),
                    )
            await db.commit()

    @commands.command(name="sell")
    async def sell_item(self, ctx, item: str, quantity: int, price: int):
        """List an item for sale on the market"""
        if quantity <= 0 or price <= 0:
            await ctx.send("⚠️ Quantity and price must be greater than 0.")
            return

        async with aiosqlite.connect(DATABASE_PATH) as db:
            # Check if seller has enough
            cursor = await db.execute(
                "SELECT quantity FROM inventory WHERE user_id = ? AND item_name = ?",
                (ctx.author.id, item),
            )
            row = await cursor.fetchone()
            if not row or row[0] < quantity:
                await ctx.send("❌ You don’t have enough of that item.")
                return

            # Remove items from seller
            await self.update_inventory(ctx.author.id, item, -quantity)

            # Add listing to market
            await db.execute(
                """
                INSERT INTO market (seller_id, item_name, quantity, price)
                VALUES (?, ?, ?, ?)
                """,
                (ctx.author.id, item, quantity, price),
            )
            await db.commit()

        await ctx.send(f"✅ {ctx.author.mention} listed **{quantity}x {item}** for **{price} gold each**.")

    @commands.command(name="market")
    async def view_market(self, ctx):
        """View items currently for sale"""
        async with aiosqlite.connect(DATABASE_PATH) as db:
            cursor = await db.execute(
                "SELECT id, seller_id, item_name, quantity, price FROM market"
            )
            listings = await cursor.fetchall()

        if not listings:
            await ctx.send("📭 The market is empty right now.")
            return

        embed = discord.Embed(title="📦 Market Listings", color=discord.Color.purple())
        for listing in listings:
            listing_id, seller_id, item, qty, price = listing
            embed.add_field(
                name=f"ID {listing_id} • {item} x{qty}",
                value=f"💰 {price} gold each (Seller: <@{seller_id}>)",
                inline=False,
            )

        await ctx.send(embed=embed)

    @commands.command(name="buy")
    async def buy_item(self, ctx, listing_id: int, quantity: int):
        """Buy items from the market"""
        if quantity <= 0:
            await ctx.send("⚠️ Quantity must be greater than 0.")
            return

        async with aiosqlite.connect(DATABASE_PATH) as db:
            # Find listing
            cursor = await db.execute(
                "SELECT seller_id, item_name, quantity, price FROM market WHERE id = ?",
                (listing_id,),
            )
            listing = await cursor.fetchone()
            if not listing:
                await ctx.send("❌ That listing does not exist.")
                return

            seller_id, item, available_qty, price = listing
            if quantity > available_qty:
                await ctx.send("❌ Not enough items available in this listing.")
                return

            total_cost = price * quantity
            buyer_gold = await self.get_balance(ctx.author.id)

            if buyer_gold < total_cost:
                await ctx.send("❌ You don’t have enough gold!")
                return

            # Transfer gold
            await self.update_balance(ctx.author.id, -total_cost)
            await self.update_balance(seller_id, total_cost)

            # Transfer item
            await self.update_inventory(ctx.author.id, item, quantity)

            # Update or remove listing
            new_qty = available_qty - quantity
            if new_qty == 0:
                await db.execute("DELETE FROM market WHERE id = ?", (listing_id,))
            else:
                await db.execute(
                    "UPDATE market SET quantity = ? WHERE id = ?",
                    (new_qty, listing_id),
                )
            await db.commit()

        await ctx.send(f"✅ {ctx.author.mention} bought **{quantity}x {item}** for **{total_cost} gold**!")


async def setup(bot):
    await bot.add_cog(Market(bot))
