import asyncio
import discord
from discord import ui
from discord.ext import commands
import random
import aiosqlite
from config import DATABASE_PATH
from database.db_manager import check_level_up 

# Base Monster Templates 
BASE_MONSTERS = [
    {"name": "Slime", "hp": 20, "attack": 3, "defense": 1, "xp": 10, "gold": 5, "gems": 0, "tier": 1, "emoji": "🟢"},
    {"name": "Rat", "hp": 25, "attack": 4, "defense": 1, "xp": 12, "gold": 6, "gems": 0, "tier": 1, "emoji": "🐀"},
    {"name": "Bat", "hp": 22, "attack": 5, "defense": 2, "xp": 15, "gold": 7, "gems": 0, "tier": 1, "emoji": "🦇"},
    {"name": "Snake", "hp": 28, "attack": 6, "defense": 2, "xp": 18, "gold": 8, "gems": 0, "tier": 1, "emoji": "🐍"},
    {"name": "Goblin", "hp": 35, "attack": 6, "defense": 3, "xp": 20, "gold": 10, "gems": 0, "tier": 1, "emoji": "👺"},
    {"name": "Wolf", "hp": 45, "attack": 8, "defense": 4, "xp": 30, "gold": 15, "gems": 1, "tier": 2, "emoji": "🐺"},
    {"name": "Skeleton", "hp": 50, "attack": 7, "defense": 5, "xp": 35, "gold": 18, "gems": 1, "tier": 2, "emoji": "💀"},
    {"name": "Bandit", "hp": 55, "attack": 9, "defense": 4, "xp": 40, "gold": 20, "gems": 1, "tier": 2, "emoji": "🥷"},
    {"name": "Ghoul", "hp": 60, "attack": 10, "defense": 5, "xp": 45, "gold": 22, "gems": 1, "tier": 2, "emoji": "👻"},
    {"name": "Dark Wolf", "hp": 65, "attack": 11, "defense": 5, "xp": 50, "gold": 25, "gems": 1, "tier": 2, "emoji": "🌑🐺"},
    {"name": "Orc", "hp": 80, "attack": 12, "defense": 6, "xp": 60, "gold": 30, "gems": 2, "tier": 3, "emoji": "👹"},
    {"name": "Troll", "hp": 100, "attack": 14, "defense": 7, "xp": 70, "gold": 35, "gems": 2, "tier": 3, "emoji": "🧌"},
    {"name": "Ogre", "hp": 120, "attack": 15, "defense": 8, "xp": 80, "gold": 40, "gems": 2, "tier": 3, "emoji": "👺"},
    {"name": "Dark Knight", "hp": 140, "attack": 18, "defense": 10, "xp": 100, "gold": 50, "gems": 2, "tier": 3, "emoji": "⚔️"},
    {"name": "Cultist", "hp": 130, "attack": 16, "defense": 9, "xp": 90, "gold": 45, "gems": 2, "tier": 3, "emoji": "🕯️"},
    {"name": "Vampire", "hp": 160, "attack": 20, "defense": 12, "xp": 130, "gold": 65, "gems": 3, "tier": 4, "emoji": "🧛"},
    {"name": "Stone Golem", "hp": 200, "attack": 18, "defense": 15, "xp": 150, "gold": 75, "gems": 3, "tier": 4, "emoji": "🪨"},
    {"name": "Minotaur", "hp": 220, "attack": 22, "defense": 14, "xp": 170, "gold": 85, "gems": 3, "tier": 4, "emoji": "🐂"},
    {"name": "Wyvern", "hp": 250, "attack": 24, "defense": 15, "xp": 200, "gold": 100, "gems": 3, "tier": 4, "emoji": "🐉"},
    {"name": "Lich Apprentice", "hp": 180, "attack": 21, "defense": 13, "xp": 140, "gold": 70, "gems": 3, "tier": 4, "emoji": "🧙‍♂️"},
    {"name": "Hydra", "hp": 300, "attack": 28, "defense": 18, "xp": 250, "gold": 120, "gems": 4, "tier": 5, "emoji": "🐉"},
    {"name": "Ancient Vampire", "hp": 280, "attack": 26, "defense": 17, "xp": 230, "gold": 115, "gems": 4, "tier": 5, "emoji": "🦇"},
    {"name": "Fire Dragon", "hp": 400, "attack": 35, "defense": 20, "xp": 350, "gold": 200, "gems": 4, "tier": 5, "emoji": "🔥🐉"},
    {"name": "Frost Giant", "hp": 370, "attack": 32, "defense": 22, "xp": 320, "gold": 180, "gems": 4, "tier": 5, "emoji": "❄️👹"},
    {"name": "Demon Lord", "hp": 500, "attack": 40, "defense": 25, "xp": 500, "gold": 300, "gems": 4, "tier": 5, "emoji": "😈"},
]

def generate_monster(player_level: int):
    """Generate monster based on player level → unlock stronger tiers as player grows."""
    if player_level <= 20:
        max_tier = 1
    elif player_level <= 40:
        max_tier = 2
    elif player_level <= 60:
        max_tier = 3
    elif player_level <= 80:
        max_tier = 4
    else:
        max_tier = 5

    candidates = [m for m in BASE_MONSTERS if m["tier"] <= max_tier]
    monster = random.choice(candidates).copy()

    # Random scaling
    monster["hp"] = int(monster["hp"] * random.uniform(0.9, 1.2))
    monster["attack"] = int(monster["attack"] * random.uniform(0.9, 1.2))
    monster["defense"] = int(monster["defense"] * random.uniform(0.9, 1.2))
    return monster

class Combat(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def player_exists(self, user_id: int):
        """Check if player is registered in database"""
        try:
            async with aiosqlite.connect(DATABASE_PATH) as db:
                cursor = await db.execute("SELECT 1 FROM players WHERE user_id = ?", (user_id,))
                return await cursor.fetchone() is not None
        except Exception as e:
            print(f"Database error in player_exists: {e}")
            return False

    async def get_player_stats(self, user_id: int):
        """Fetch player stats including equipped gear."""
        async with aiosqlite.connect(DATABASE_PATH) as db:
            cursor = await db.execute(
                "SELECT level, hp, attack, defense FROM players WHERE user_id = ?",
                (user_id,)
            )
            result = await cursor.fetchone()
            if not result:
                return None
            stats = {"level": result[0], "hp": result[1], "attack": result[2], "defense": result[3]}

            # Add equipment bonuses
            cursor = await db.execute(
                "SELECT weapon_attack, armor_defense FROM equipment WHERE user_id = ?", (user_id,)
            )
            eq = await cursor.fetchone()
            if eq:
                stats["attack"] += eq[0] or 0
                stats["defense"] += eq[1] or 0

            return stats


    async def add_currency(self, user_id: int, xp: int = 0, gold: int = 0, gems: int = 0):
        """Update player currencies directly in players table"""
        try:
            async with aiosqlite.connect(DATABASE_PATH) as db:
                await db.execute(
                    "UPDATE players SET xp = xp + ?, gold = gold + ?, gems = gems + ? WHERE user_id = ?",
                    (xp, gold, gems, user_id)
                )
                await db.commit()
        except Exception as e:
            print(f"Database error in add_currency: {e}")

    @commands.command(name="hunt")
    @commands.cooldown(1, 10, commands.BucketType.user)
    async def hunt(self, ctx):
        """Hunt a random monster and get rewards"""
        user_id = ctx.author.id

        try:
            # Check if player is registered
            if not await self.player_exists(user_id):
                print("Player not registered")
                await ctx.send(f"⚠️ {ctx.author.mention}, you must `!register` first.")
                return

            # Fetch player stats
            player = await self.get_player_stats(user_id)
            if not player:
                print("Failed to retrieve player stats")
                await ctx.send(f"⚠️ {ctx.author.mention}, could not retrieve your stats. Please try again later.")
                return

            # Generate monster based on player level
            monster = generate_monster(player["level"])
            player_hp = player["hp"]
            monster_hp = monster["hp"]

            # Initialize embed
            embed = discord.Embed(
                title=f"⚔️ {ctx.author.display_name} went hunting!",
                description=f"You encountered {monster['emoji']} **{monster['name']}**!",
                color=discord.Color.blue()
            )
            embed.add_field(
                name="🩸 Battle",
                value=f"Player HP: `{player_hp}` | {monster['name']} HP: `{monster_hp}`",
                inline=False
            )
            message = await ctx.send(embed=embed)

            # Battle simulation
            rounds = 0
            while player_hp > 0 and monster_hp > 0:
                rounds += 1
                # Player attacks monster
                player_damage = max(1, player["attack"] - monster["defense"])  # Minimum 1 damage
                monster_hp -= player_damage
                battle_status = f"Round {rounds}: You give {player_damage} damage to {monster['name']} (Monster HP: {max(0, monster_hp)})."

                # Monster attacks player (if still alive)
                if monster_hp > 0:
                    monster_damage = max(1, monster["attack"] - player["defense"])  # Minimum 1 damage
                    player_hp -= monster_damage
                    battle_status += f"\nRound {rounds}: You take {monster_damage} damage from {monster['name']} (Your HP: {max(0, player_hp)})."

                # Update embed with current battle status
                embed.set_field_at(
                    0,
                    name="🩸 Battle",
                    value=battle_status,
                    inline=False
                )
                await message.edit(embed=embed)
                await asyncio.sleep(2)  # Delay for readability (adjust as needed)

                # Prevent infinite battles
                if rounds > 50:
                    battle_status += "\nBattle ended due to too many rounds!"
                    embed.set_field_at(0, name="🩸 Battle", value=battle_status, inline=False)
                    await message.edit(embed=embed)
                    return

            # Determine outcome
            if player_hp <= 0:
                embed.color = discord.Color.red()
                embed.add_field(
                    name="📊 Your Stats",
                    value=f"Level: `{player['level']}`\nHP: `0`\nAttack: `{player['attack']}`\nDefense: `{player['defense']}`",
                    inline=False
                )
                embed.set_footer(text="You Looses !")
                await message.edit(embed=embed)
                return

            # Player wins, add rewards
            xp, gold, gems = monster["xp"], monster["gold"], monster["gems"]
            await self.add_currency(user_id, xp=xp, gold=gold, gems=gems)

            # After giving XP/Gold/Gems
            new_stats = await check_level_up(user_id)
            if new_stats:
                embed.add_field(
                    name="⬆️ Level Up!",
                    value=(
                        f"🎉 You reached **Level {new_stats['level']}**!\n"
                        f"HP: `{new_stats['hp']}` | Attack: `{new_stats['attack']}` | Defense: `{new_stats['defense']}`"
                    ),
                    inline=False
                )

            # Update embed for victory
            embed.color = discord.Color.green()
            embed.add_field(
                name="📊 Your Stats",
                value=f"Level: `{player['level']}`\nHP: `{player_hp}`\nAttack: `{player['attack']}`\nDefense: `{player['defense']}`",
                inline=False
            )
            embed.add_field(
                name="🎁 Rewards",
                value=f"⭐ XP: `{xp}`\n💰 Gold: `{gold}`\n💎 Gems: `{gems}`",
                inline=False
            )
            embed.set_footer(text="You Win, Keep hunting to grow stronger!")
            await message.edit(embed=embed)

        except Exception as e:
            print(f"Error in hunt command: {e}")
            await ctx.send(f"⚠️ An error occurred: {str(e)}")

async def setup(bot):
    await bot.add_cog(Combat(bot))