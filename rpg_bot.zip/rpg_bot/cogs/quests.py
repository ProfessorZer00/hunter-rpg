import discord
from discord.ext import commands
import aiosqlite
import random
from config import DATABASE_PATH

# Monster list with tier info
MONSTERS = [
    {"name": "Slime", "xp": 10, "gold": 5, "tier": 1},
    {"name": "Rat", "xp": 12, "gold": 6, "tier": 1},
    {"name": "Bat", "xp": 15, "gold": 7, "tier": 1},
    {"name": "Snake", "xp": 18, "gold": 8, "tier": 1},
    {"name": "Goblin", "xp": 20, "gold": 10, "tier": 1},
    {"name": "Wolf", "xp": 30, "gold": 15, "tier": 2},
    {"name": "Skeleton", "xp": 35, "gold": 18, "tier": 2},
    {"name": "Bandit", "xp": 40, "gold": 20, "tier": 2},
    {"name": "Ghoul", "xp": 45, "gold": 22, "tier": 2},
    {"name": "Dark Wolf", "xp": 50, "gold": 25, "tier": 2},
    {"name": "Orc", "xp": 60, "gold": 30, "tier": 3},
    {"name": "Troll", "xp": 70, "gold": 35, "tier": 3},
    {"name": "Ogre", "xp": 80, "gold": 40, "tier": 3},
    {"name": "Dark Knight", "xp": 100, "gold": 50, "tier": 3},
    {"name": "Cultist", "xp": 90, "gold": 45, "tier": 3},
    {"name": "Vampire", "xp": 130, "gold": 65, "tier": 4},
    {"name": "Stone Golem", "xp": 150, "gold": 75, "tier": 4},
    {"name": "Minotaur", "xp": 170, "gold": 85, "tier": 4},
    {"name": "Wyvern", "xp": 200, "gold": 100, "tier": 4},
    {"name": "Lich Apprentice", "xp": 140, "gold": 70, "tier": 4},
    {"name": "Hydra", "xp": 250, "gold": 120, "tier": 5},
    {"name": "Ancient Vampire", "xp": 230, "gold": 115, "tier": 5},
    {"name": "Fire Dragon", "xp": 350, "gold": 200, "tier": 5},
    {"name": "Frost Giant", "xp": 320, "gold": 180, "tier": 5},
    {"name": "Demon Lord", "xp": 500, "gold": 300, "tier": 5},
]

# Kill ranges per tier
TIER_KILL_RANGES = {
    1: (20, 30),
    2: (15, 25),
    3: (15, 20),
    4: (10, 15),
    5: (5, 10)
}

def get_allowed_tiers(level: int):
    if level <= 10:
        return [1]
    elif level <= 20:
        return [1, 2]
    elif level <= 30:
        return [2, 3]
    elif level <= 40:
        return [3, 4]
    else:
        return [4, 5]

def generate_quest_templates():
    templates = []
    for monster in MONSTERS:
        goal = random.randint(*TIER_KILL_RANGES[monster["tier"]])
        reward_xp = int(monster["xp"] * random.uniform(0.8, 1.2))
        reward_gold = int(monster["gold"] * random.uniform(0.8, 1.2))
        templates.append({
            "quest_name": f"Defeat {monster['name']}s",
            "monster_name": monster["name"],
            "goal": goal,
            "reward_xp": reward_xp,
            "reward_gold": reward_gold,
            "reward_item": None
        })
    return templates

QUEST_TEMPLATES = generate_quest_templates()

class Quest(commands.Cog):
    """RPG Quests Cog - Assign, track, and complete quests with rewards."""

    def __init__(self, bot):
        self.bot = bot

    async def get_active_quest(self, user_id: int):
        async with aiosqlite.connect(DATABASE_PATH) as db:
            cursor = await db.execute(
                "SELECT quest_name, monster_name, progress, goal, reward_xp, reward_gold, reward_item "
                "FROM quests WHERE user_id = ? AND completed = 0",
                (user_id,),
            )
            return await cursor.fetchone()

    @commands.command(name="quest")
    async def quest(self, ctx):
        user_id = ctx.author.id
        quest = await self.get_active_quest(user_id)

        if quest:
            q_name, monster_name, progress, goal, xp, gold, _ = quest
            embed = discord.Embed(title="📜 Current Quest", color=discord.Color.blue())
            embed.add_field(name="Quest", value=f"📝 {q_name}", inline=False)
            embed.add_field(name="Target", value=f"👹 {monster_name}", inline=True)
            embed.add_field(name="Progress", value=f"📈 {progress}/{goal}", inline=True)
            embed.add_field(name="Rewards", value=f"💠 {xp} XP | 💰 {gold} Gold", inline=False)
            await ctx.send(embed=embed)
            return

        # Assign a new random quest
        template = random.choice(QUEST_TEMPLATES)
        quest_name = template["quest_name"]
        monster_name = template["monster_name"]
        goal = template["goal"]
        reward_xp = template["reward_xp"]
        reward_gold = template["reward_gold"]

        async with aiosqlite.connect(DATABASE_PATH) as db:
            await db.execute(
                "INSERT INTO quests (user_id, quest_name, monster_name, progress, goal, reward_xp, reward_gold, reward_item, completed) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, NULL, 0)",
                (user_id, quest_name, monster_name, 0, goal, reward_xp, reward_gold),
            )
            await db.commit()

        embed = discord.Embed(
            title="🎯 New Quest Assigned!",
            description=f"**{quest_name}**\nTarget: {monster_name}\nGoal: {goal} monsters",
            color=discord.Color.green()
        )
        embed.add_field(name="Rewards", value=f"💠 XP: {reward_xp} | 💰 Gold: {reward_gold}")
        await ctx.send(embed=embed)

    @commands.command(name="progress")
    async def progress(self, ctx):
        """Check quest progress (cannot manually increase anymore)."""
        user_id = ctx.author.id
        quest = await self.get_active_quest(user_id)

        if not quest:
            embed = discord.Embed(
                title="❌ No Active Quest",
                description="Use `!quest` to get a new quest!",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return

        q_name, monster_name, progress, goal, xp, gold, _ = quest
        embed = discord.Embed(
            title="📈 Quest Progress",
            description=f"**{q_name}**\nTarget: {monster_name}\nProgress: {progress}/{goal}",
            color=discord.Color.blue()
        )
        embed.add_field(name="Rewards", value=f"💠 {xp} XP | 💰 {gold} Gold")
        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Quest(bot))
