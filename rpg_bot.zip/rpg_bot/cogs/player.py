import discord
from discord.ext import commands
import aiosqlite
from config import DATABASE_PATH, DEFAULT_HP, DEFAULT_ATTACK, DEFAULT_DEFENSE, STARTING_GOLD, STARTING_GEMS, DEFAULT_CLASS


class Player(commands.Cog):
    """Player management cog: registration, profile display, and player checks."""

    def __init__(self, bot):
        self.bot = bot

    async def player_exists(self, user_id: int) -> bool:
        """Check if a player exists in the database."""
        async with aiosqlite.connect(DATABASE_PATH) as db:
            cursor = await db.execute("SELECT 1 FROM players WHERE user_id = ?", (user_id,))
            return await cursor.fetchone() is not None

    @commands.command(name="register", aliases=["reg"])
    async def register(self, ctx: commands.Context):
        """Register a new player with default stats."""
        user_id = ctx.author.id

        if await self.player_exists(user_id):
            await ctx.send(f"⚠️ {ctx.author.mention}, you are already registered!")
            return

        async with aiosqlite.connect(DATABASE_PATH) as db:
            await db.execute(
                """
                INSERT INTO players (user_id, name, class, level, xp, hp, attack, defense, gold, gems)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    user_id,
                    ctx.author.name,
                    DEFAULT_CLASS,
                    1,  # starting level
                    0,  # starting XP
                    DEFAULT_HP,
                    DEFAULT_ATTACK,
                    DEFAULT_DEFENSE,
                    STARTING_GOLD,
                    STARTING_GEMS,
                ),
            )
            await db.commit()

        await ctx.send(f"✅ Welcome {ctx.author.mention}! Your adventure begins now. Use `!profile` or `!stat` to view stats.")

    @commands.command(name="profile", aliases=["stat"])
    async def profile(self, ctx: commands.Context, member: discord.Member = None):
        """Show the profile of a player."""
        target = member or ctx.author

        async with aiosqlite.connect(DATABASE_PATH) as db:
            cursor = await db.execute(
                "SELECT class, level, xp, hp, attack, defense, gold, gems FROM players WHERE user_id = ?",
                (target.id,),
            )
            row = await cursor.fetchone()

        if not row:
            await ctx.send(f"⚠️ {target.mention} is not registered. Use `!register` first.")
            return

        player_class, level, xp, hp, attack, defense, gold, gems = row

        embed = discord.Embed(
            title=f"{target.name}'s Profile",
            color=discord.Color.blue(),
        )
        embed.add_field(name="👤 Class", value=player_class)
        embed.add_field(name="📊 Level", value=level)
        embed.add_field(name="🌟 XP", value=xp)
        embed.add_field(name="❤️ HP", value=hp)
        embed.add_field(name="🗡️ Attack", value=attack)
        embed.add_field(name="🛡️ Defense", value=defense)
        embed.add_field(name="🪙 Gold", value=gold)
        embed.add_field(name="💎 Gems", value=gems)

        await ctx.send(embed=embed)


async def setup(bot: commands.Bot):
    """Setup function to load the Player cog."""
    await bot.add_cog(Player(bot))
