import discord
from discord.ext import commands
import aiosqlite
from config import DATABASE_PATH


# Confirmation view with buttons
class ConfirmView(discord.ui.View):
    def __init__(self, ctx, member, callback):
        super().__init__(timeout=30)
        self.ctx = ctx
        self.member = member
        self.callback = callback

    @discord.ui.button(label="✅ Confirm", style=discord.ButtonStyle.green)
    async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            await interaction.response.send_message("❌ Only the command author can confirm.", ephemeral=True)
            return
        await self.callback(self.member)
        await interaction.response.edit_message(content="✅ Action confirmed!", view=None)

    @discord.ui.button(label="❌ Cancel", style=discord.ButtonStyle.red)
    async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
        if interaction.user != self.ctx.author:
            await interaction.response.send_message("❌ Only the command author can cancel.", ephemeral=True)
            return
        await interaction.response.edit_message(content="❌ Action canceled.", view=None)


class Admin(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    async def player_exists(self, user_id: int):
        async with aiosqlite.connect(DATABASE_PATH) as db:
            cursor = await db.execute("SELECT 1 FROM players WHERE user_id = ?", (user_id,))
            return await cursor.fetchone() is not None

    @commands.command(name="resetplayer")
    @commands.is_owner()
    async def reset_player(self, ctx, member: discord.Member):
        """Reset a player's data with confirmation"""

        async def do_reset(member):
            async with aiosqlite.connect(DATABASE_PATH) as db:
                await db.execute("DELETE FROM players WHERE user_id = ?", (member.id,))
                await db.execute("DELETE FROM inventory WHERE user_id = ?", (member.id,))
                await db.commit()
            embed = discord.Embed(
                title="♻️ Player Reset",
                description=f"{member.mention}'s data has been wiped.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)

        embed = discord.Embed(
            title="⚠️ Confirmation Needed",
            description=f"Do you really want to reset {member.mention}'s data?",
            color=discord.Color.orange()
        )
        await ctx.send(embed=embed, view=ConfirmView(ctx, member, do_reset))

    @commands.command(name="setstat")
    @commands.is_owner()
    async def set_stat(self, ctx, member: discord.Member, stat: str, value: int):
        """Set a specific player stat"""
        allowed = ["hp", "gold", "gems", "level", "xp", "attack", "defense"]
        if stat.lower() not in allowed:
            await ctx.send(f"⚠️ Invalid stat. Allowed: {', '.join(allowed)}")
            return

        async with aiosqlite.connect(DATABASE_PATH) as db:
            if not await self.player_exists(member.id):
                await ctx.send(f"⚠️ {member.mention} is not registered.")
                return
            await db.execute(
                f"UPDATE players SET {stat} = ? WHERE user_id = ?",
                (value, member.id),
            )
            await db.commit()

        embed = discord.Embed(
            title="📊 Stat Updated",
            description=f"✅ {member.mention}'s **{stat}** has been set to `{value}`.",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)

    @commands.command(name="givegold")
    @commands.is_owner()
    async def give_gold(self, ctx, member: discord.Member, amount: int):
        """Give gold to a player"""
        async with aiosqlite.connect(DATABASE_PATH) as db:
            if not await self.player_exists(member.id):
                await ctx.send(f"⚠️ {member.mention} is not registered.")
                return
            await db.execute(
                "UPDATE players SET gold = gold + ? WHERE user_id = ?",
                (amount, member.id),
            )
            await db.commit()

        embed = discord.Embed(
            title="💰 Gold Granted",
            description=f"Gave **{amount}** gold to {member.mention}.",
            color=discord.Color.gold()
        )
        await ctx.send(embed=embed)

    @commands.command(name="givegems")
    @commands.is_owner()
    async def give_gems(self, ctx, member: discord.Member, amount: int):
        """Give gems to a player"""
        async with aiosqlite.connect(DATABASE_PATH) as db:
            if not await self.player_exists(member.id):
                await ctx.send(f"⚠️ {member.mention} is not registered.")
                return
            await db.execute(
                "UPDATE players SET gems = gems + ? WHERE user_id = ?",
                (amount, member.id),
            )
            await db.commit()

        embed = discord.Embed(
            title="💎 Gems Granted",
            description=f"Gave **{amount}** gems to {member.mention}.",
            color=discord.Color.blue()
        )
        await ctx.send(embed=embed)

    @commands.command(name="listplayers")
    @commands.is_owner()
    async def list_players(self, ctx):
        """List all registered players"""
        async with aiosqlite.connect(DATABASE_PATH) as db:
            cursor = await db.execute("SELECT name, level, gold, gems FROM players")
            players = await cursor.fetchall()

        if not players:
            await ctx.send("⚠️ No players registered yet.")
            return

        embed = discord.Embed(title="📜 Registered Players", color=discord.Color.purple())
        for name, level, gold, gems in players:
            embed.add_field(
                name=name,
                value=f"Lvl {level} | 💰 {gold} | 💎 {gems}",
                inline=False,
            )

        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Admin(bot))
