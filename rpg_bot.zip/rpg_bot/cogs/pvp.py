import discord
from discord.ext import commands
import aiosqlite
import random
from config import DATABASE_PATH
import time


class PvP(commands.Cog):
    """Player vs Player combat system with pets and stats included."""

    def __init__(self, bot):
        self.bot = bot
        self.duels = {}  # Track ongoing duels {challenger_id: opponent_id}
        self.cooldowns = {}  # Track last duel timestamp per player {user_id: last_duel_time}

        self.cooldown_seconds = 60  # cooldown per player

    async def get_player_stats(self, user_id: int):
        """Fetch player stats including pet bonuses if available."""
        async with aiosqlite.connect(DATABASE_PATH) as db:
            cursor = await db.execute(
                "SELECT hp, attack, defense FROM players WHERE user_id = ?",
                (user_id,),
            )
            row = await cursor.fetchone()
            if not row:
                return None
            hp, attack, defense = row

            # Add pet bonuses if exists
            cursor = await db.execute(
                "SELECT hp_bonus, attack_bonus, defense_bonus FROM pets WHERE user_id = ?",
                (user_id,),
            )
            pet = await cursor.fetchone()
            if pet:
                hp += pet[0]
                attack += pet[1]
                defense += pet[2]

            return {"hp": hp, "attack": attack, "defense": defense}

    def check_cooldown(self, user_id: int):
        """Check if player is on cooldown"""
        last_time = self.cooldowns.get(user_id)
        if last_time and time.time() - last_time < self.cooldown_seconds:
            return self.cooldown_seconds - (time.time() - last_time)
        return 0

    def set_cooldown(self, user_id: int):
        """Set current timestamp for cooldown tracking"""
        self.cooldowns[user_id] = time.time()

    @commands.command(name="duel")
    async def duel(self, ctx, member: discord.Member):
        """Challenge another player to a duel."""
        if member.id == ctx.author.id:
            await ctx.send("⚠️ You cannot duel yourself!")
            return

        # Check cooldown
        cd = self.check_cooldown(ctx.author.id)
        if cd > 0:
            await ctx.send(f"⏳ You are on cooldown! Try again in {int(cd)} seconds.")
            return

        if ctx.author.id in self.duels or member.id in self.duels:
            await ctx.send("⚔️ One of you is already in a duel!")
            return

        self.duels[ctx.author.id] = member.id
        self.set_cooldown(ctx.author.id)
        embed = discord.Embed(
            title="⚔️ Duel Challenge!",
            description=f"{ctx.author.mention} has challenged {member.mention} to a duel!\nType `!accept` to fight!",
            color=discord.Color.orange()
        )
        embed.set_footer(text="PvP System")
        await ctx.send(embed=embed)

    @commands.command(name="accept")
    async def accept(self, ctx):
        """Accept a duel challenge."""
        # Check cooldown
        cd = self.check_cooldown(ctx.author.id)
        if cd > 0:
            await ctx.send(f"⏳ You are on cooldown! Try again in {int(cd)} seconds.")
            return

        opponent_id = None
        for challenger, opponent in self.duels.items():
            if opponent == ctx.author.id:
                opponent_id = challenger
                break

        if not opponent_id:
            await ctx.send("❌ You don’t have a pending duel request.")
            return

        challenger = await self.bot.fetch_user(opponent_id)
        opponent = ctx.author

        # Fetch stats
        challenger_stats = await self.get_player_stats(challenger.id)
        opponent_stats = await self.get_player_stats(opponent.id)

        if not challenger_stats or not opponent_stats:
            await ctx.send("❌ One of the players is not registered.")
            self.duels.pop(opponent_id, None)
            return

        # Set cooldown for both players
        self.set_cooldown(challenger.id)
        self.set_cooldown(opponent.id)

        # Notify duel start
        embed_start = discord.Embed(
            title="🔥 Duel Begins!",
            description=f"{challenger.mention} vs {opponent.mention}",
            color=discord.Color.red()
        )
        embed_start.add_field(name="⚔️ Challenger HP", value=challenger_stats["hp"])
        embed_start.add_field(name="🛡️ Opponent HP", value=opponent_stats["hp"])
        await ctx.send(embed=embed_start)

        # Battle loop
        turn = random.choice([challenger.id, opponent.id])
        log = []

        while challenger_stats["hp"] > 0 and opponent_stats["hp"] > 0:
            attacker = challenger if turn == challenger.id else opponent
            defender = opponent if turn == challenger.id else challenger
            atk_stats = challenger_stats if turn == challenger.id else opponent_stats
            def_stats = opponent_stats if turn == challenger.id else challenger_stats

            damage = max(1, atk_stats["attack"] - def_stats["defense"] + random.randint(-2, 2))
            def_stats["hp"] -= damage
            log.append(f"{attacker.name} hits {defender.name} for {damage} damage! ({def_stats['hp']} HP left)")

            turn = defender.id

        if challenger_stats["hp"] > 0:
            winner, loser = challenger, opponent
        else:
            winner, loser = opponent, challenger

        self.duels.pop(opponent_id, None)

        result_embed = discord.Embed(
            title="🏆 Duel Result",
            description=f"Winner: {winner.mention}\nLoser: {loser.mention}",
            color=discord.Color.green()
        )
        result_embed.add_field(name="📝 Battle Log (Last 10 Moves)", value="\n".join(log[-10:]), inline=False)
        await ctx.send(embed=result_embed)


async def setup(bot):
    await bot.add_cog(PvP(bot))
