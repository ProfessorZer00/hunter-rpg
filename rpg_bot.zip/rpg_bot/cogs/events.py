import discord
from discord.ext import commands
import aiosqlite
import datetime
from config import DATABASE_PATH
import random

class Events(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="daily")
    @commands.cooldown(1, 86400, commands.BucketType.user)  # 1 use per 24 hours per user
    async def daily(self, ctx):
        """Claim your daily login reward using a button."""
        user_id = ctx.author.id
        today = datetime.date.today().isoformat()

        # Define the interactive button
        class DailyButton(discord.ui.View):
            def __init__(self):
                super().__init__(timeout=60)  # Button expires after 60 seconds

            @discord.ui.button(label="Claim Daily Reward", style=discord.ButtonStyle.green)
            async def claim(self, interaction: discord.Interaction, button: discord.ui.Button):
                # Only the command invoker can click the button
                if interaction.user.id != ctx.author.id:
                    await interaction.response.send_message(
                        "⚠️ This button is not for you!", ephemeral=True
                    )
                    return

                try:
                    async with aiosqlite.connect(DATABASE_PATH) as db:
                        # Fetch player info
                        cursor = await db.execute(
                            "SELECT gold, gems, xp, last_daily FROM players WHERE user_id = ?",
                            (user_id,)
                        )
                        row = await cursor.fetchone()

                        if not row:
                            await interaction.response.send_message(
                                "⚠️ You are not registered. Use `!register` first.", ephemeral=True
                            )
                            return

                        _, _, _, last_daily = row

                        # Check if already claimed today
                        if last_daily == today:
                            await interaction.response.send_message(
                                "⏳ You already claimed your daily reward today. Come back tomorrow!", ephemeral=True
                            )
                            return

                        # Rewards
                        reward_gold = random.randint(100,150)
                        reward_gems = random.randint(1,3)
                        reward_xp = random.randint(15,20)

                        # Update database
                        await db.execute(
                            "UPDATE players SET gold = gold + ?, gems = gems + ?, xp = xp + ?, last_daily = ? WHERE user_id = ?",
                            (reward_gold, reward_gems, reward_xp, today, user_id)
                        )
                        await db.commit()

                    # Send reward embed
                    embed = discord.Embed(
                        title="🎁 Daily Reward Claimed!",
                        description=f"Nice work, {ctx.author.mention}! Here’s your reward:",
                        color=discord.Color.green(),
                    )
                    embed.add_field(name="Gold", value=f"💰 {reward_gold}")
                    embed.add_field(name="Gems", value=f"💎 {reward_gems}")
                    embed.add_field(name="XP", value=f"⭐ {reward_xp}")
                    embed.set_footer(text="Come back tomorrow for more rewards!")

                    # Edit message to show embed and remove button
                    await interaction.response.edit_message(content=None, embed=embed, view=None)

                except Exception as e:
                    await interaction.response.send_message(
                        f"❌ An error occurred while processing your daily reward.\n```{e}```", ephemeral=True
                    )

        # Send initial message with button
        view = DailyButton()
        await ctx.send(f"🎁 {ctx.author.mention}, click the button below to claim your daily reward!", view=view)

async def setup(bot):
    await bot.add_cog(Events(bot))
