import discord
from discord.ext import commands
import aiosqlite
import random
from config import DATABASE_PATH

class Economy(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # Utility functions
    async def update_currency(self, user_id: int, gold_change: int = 0, gems_change: int = 0):
        """Update player's gold and gems (positive or negative)."""
        async with aiosqlite.connect(DATABASE_PATH) as db:
            await db.execute(
                "UPDATE players SET gold = gold + ?, gems = gems + ? WHERE user_id = ?",
                (gold_change, gems_change, user_id),
            )
            await db.commit()

    async def get_balance(self, user_id: int):
        """Get player's current gold and gems."""
        async with aiosqlite.connect(DATABASE_PATH) as db:
            cursor = await db.execute("SELECT gold, gems FROM players WHERE user_id = ?", (user_id,))
            row = await cursor.fetchone()
        return row if row else (0, 0)

    # Commands
    @commands.command(name="balance", aliases=["bal", "money"])
    async def balance(self, ctx, member: discord.Member = None):
        """Check balance of yourself or another player."""
        target = member or ctx.author
        gold, gems = await self.get_balance(target.id)

        embed = discord.Embed(title=f"{target.name}'s Balance", color=discord.Color.gold())
        embed.add_field(name="Gold", value=f"💰 {gold}")
        embed.add_field(name="Gems", value=f"💎 {gems}")

        await ctx.send(embed=embed)


    @commands.command(name="earn")
    @commands.cooldown(1, 43200, commands.BucketType.user)  # 12h cooldown
    async def earn(self, ctx):
        """Simple daily work command to earn gold and gems."""
        gold_earned = 50
        gems_earned = 1

        await self.update_currency(ctx.author.id, gold_earned, gems_earned)
        await ctx.send(
            f"✅ {ctx.author.mention}, you earned **{gold_earned} gold** and **{gems_earned} gem**!"
        )

    @earn.error
    async def earn_error(self, ctx, error):
        """Handle cooldown error for earn command"""
        if isinstance(error, commands.CommandOnCooldown):
            hours = int(error.retry_after // 3600)
            minutes = int((error.retry_after % 3600) // 60)
            seconds = int(error.retry_after % 60)

            time_left = []
            if hours > 0:
                time_left.append(f"{hours}h")
            if minutes > 0:
                time_left.append(f"{minutes}m")
            if seconds > 0:
                time_left.append(f"{seconds}s")

            await ctx.send(
                f"⏳ {ctx.author.mention}, you can use **!earn** again in **{' '.join(time_left)}**."
            )


    @commands.command(name="pay")
    async def pay(self, ctx, member: discord.Member, amount: int):
        """Pay gold to another player with confirmation."""
        if amount <= 0:
            return await ctx.send("⚠️ Amount must be greater than 0.")

        gold, _ = await self.get_balance(ctx.author.id)
        if gold < amount:
            return await ctx.send("❌ You don't have enough gold!")

        # Confirmation buttons
        class Confirm(discord.ui.View):
            def __init__(self, cog: "Economy"):
                super().__init__(timeout=30)
                self.cog = cog  # keep reference to Economy cog

            @discord.ui.button(label="✅ Confirm", style=discord.ButtonStyle.green)
            async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
                if interaction.user != ctx.author:
                    return await interaction.response.send_message(
                        "⚠️ This confirmation is not for you!", ephemeral=True
                    )

                await self.cog.update_currency(ctx.author.id, gold_change=-amount)
                await self.cog.update_currency(member.id, gold_change=amount)
                await interaction.response.edit_message(
                    content=f"💰 {ctx.author.mention} paid {member.mention} **{amount} gold**!",
                    view=None
                )

            @discord.ui.button(label="❌ Cancel", style=discord.ButtonStyle.red)
            async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
                if interaction.user != ctx.author:
                    return await interaction.response.send_message(
                        "⚠️ This confirmation is not for you!", ephemeral=True
                    )
                await interaction.response.edit_message(content="❌ Transaction cancelled.", view=None)

        view = Confirm(self)
        await ctx.send(
            f"💰 {ctx.author.mention}, do you confirm sending **{amount} gold** to {member.mention}?",
            view=view
        )

    @commands.command(name="paygem")
    async def gem_gift(self, ctx, member: discord.Member, amount: int):
        """Gift gems to another player with confirmation."""
        if amount <= 0:
            return await ctx.send("⚠️ Amount must be greater than 0.")

        _, gems = await self.get_balance(ctx.author.id)
        if gems < amount:
            return await ctx.send("❌ You don't have enough gems!")

        # Confirmation buttons
        class Confirm(discord.ui.View):
            def __init__(self, cog: "Economy"):
                super().__init__(timeout=30)
                self.cog = cog

            @discord.ui.button(label="✅ Confirm", style=discord.ButtonStyle.green)
            async def confirm(self, interaction: discord.Interaction, button: discord.ui.Button):
                if interaction.user != ctx.author:
                    return await interaction.response.send_message(
                        "⚠️ This confirmation is not for you!", ephemeral=True
                    )

                await self.cog.update_currency(ctx.author.id, gems_change=-amount)
                await self.cog.update_currency(member.id, gems_change=amount)
                await interaction.response.edit_message(
                    content=f"💎 {ctx.author.mention} gifted {member.mention} **{amount} gems**!",
                    view=None
                )

            @discord.ui.button(label="❌ Cancel", style=discord.ButtonStyle.red)
            async def cancel(self, interaction: discord.Interaction, button: discord.ui.Button):
                if interaction.user != ctx.author:
                    return await interaction.response.send_message(
                        "⚠️ This confirmation is not for you!", ephemeral=True
                    )
                await interaction.response.edit_message(content="❌ Transaction cancelled.", view=None)

        view = Confirm(self)
        await ctx.send(
            f"💎 {ctx.author.mention}, do you confirm gifting **{amount} gems** to {member.mention}?",
            view=view
        )

    # Leaderboards
    @commands.command(name="leaderboard", aliases=["lb", "top"])
    async def leaderboard(self, ctx, currency: str = "gold"):
        """
        Show leaderboard.
        Usage: !leaderboard gold -> leaderboard by gold (default)
               !leaderboard gems -> leaderboard by gems
        """
        currency = currency.lower()
        if currency not in ["gold", "gem"]:
            await ctx.send("⚠️ Invalid currency! Use `gold` or `gems`.")
            return

        async with aiosqlite.connect(DATABASE_PATH) as db:
            cursor = await db.execute(
                f"SELECT name, gold, gems FROM players ORDER BY {currency} DESC LIMIT 10"
            )
            rows = await cursor.fetchall()

        if not rows:
            await ctx.send("❌ No players found on the leaderboard.")
            return

        title = "🏆 Leaderboard - Richest Players by Gold" if currency == "gold" else "🏆 Leaderboard - Richest Players by Gems"
        embed = discord.Embed(title=title, color=discord.Color.purple())

        for i, (name, gold, gems) in enumerate(rows, start=1):
            if currency == "gold":
                embed.add_field(name=f"#{i} {name}", value=f"💰 {gold} gold | 💎 {gems} gems", inline=False)
            else:
                embed.add_field(name=f"#{i} {name}", value=f"💎 {gems} gems | 💰 {gold} gold", inline=False)

        await ctx.send(embed=embed)

    # Mine Command
    @commands.command(name="mine")
    @commands.cooldown(1, 600, commands.BucketType.user)  # 10 Minutes cooldown
    async def mine(self, ctx):
        """Mine for gold, XP, and gems."""
        gold_found = random.randint(40, 50)
        xp_gained = random.randint(15, 20)
        gems_found = 1 if random.randint(1, 5) <= 10 else 0  # 10% chance to find a gem

        # Update player's gold, XP, and gems
        await self.update_currency(ctx.author.id, gold_change=gold_found, xp_change=xp_gained, gems_change=gems_found)

        # Check for level-up
        level_up_info = await self.check_level_up(ctx.author.id)

        # Build result message
        msg = f"⛏️ {ctx.author.mention} mined and found **{gold_found} gold**, **{xp_gained} XP**"
        if gems_found:
            msg += f", and **{gems_found} gem** 💎"
        msg += "!"

        if level_up_info:
            msg += f"\n🎉 You leveled up to **Level {level_up_info['level']}**! Stats - HP: {level_up_info['hp']}, Attack: {level_up_info['attack']}, Defense: {level_up_info['defense']}"

        await ctx.send(msg)

    # Cutting Command
    @commands.command(name="cut")
    @commands.cooldown(1, 600, commands.BucketType.user)  # 10 Minutes  cooldown
    async def cut(self, ctx):
        """Chop trees to earn gold, XP, and gems."""
        gold_found = random.randint(50, 60)
        xp_gained = random.randint(15, 25)
        gems_found = 1 if random.randint(1, 5) <= 8 else 0  # 8% chance to find a gem

        # Update player's gold, XP, and gems
        await self.update_currency(ctx.author.id, gold_change=gold_found, xp_change=xp_gained, gems_change=gems_found)

        # Check for level-up
        level_up_info = await self.check_level_up(ctx.author.id)

        # Build result message
        msg = f"🌲 {ctx.author.mention} chopped trees and earned **{gold_found} gold**, **{xp_gained} XP**"
        if gems_found:
            msg += f", and **{gems_found} gem** 💎"
        msg += "!"

        if level_up_info:
            msg += f"\n🎉 You leveled up to **Level {level_up_info['level']}**! Stats - HP: {level_up_info['hp']}, Attack: {level_up_info['attack']}, Defense: {level_up_info['defense']}"

        await ctx.send(msg)

    # Farming Command
    @commands.command(name="farm")
    @commands.cooldown(1, 300, commands.BucketType.user)  # 5 Minutes cooldown
    async def farm(self, ctx):
        """Farm crops to earn gold, XP, and gems."""
        gold_found = random.randint(70, 80)
        xp_gained = random.randint(30, 40)
        gems_found = 1 if random.randint(1, 5) <= 5 else 0  # 5% chance to find a gem

        # Update player's gold, XP, and gems
        await self.update_currency(ctx.author.id, gold_change=gold_found, xp_change=xp_gained, gems_change=gems_found)

        # Check for level-up
        level_up_info = await self.check_level_up(ctx.author.id)

        # Build result message
        msg = f"🌾 {ctx.author.mention} farmed and earned **{gold_found} gold**, **{xp_gained} XP**"
        if gems_found:
            msg += f", and **{gems_found} gem** 💎"
        msg += "!"

        if level_up_info:
            msg += f"\n🎉 You leveled up to **Level {level_up_info['level']}**! Stats - HP: {level_up_info['hp']}, Attack: {level_up_info['attack']}, Defense: {level_up_info['defense']}"

        await ctx.send(msg)

    @mine.error
    async def mine_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            seconds = int(error.retry_after)
            hours = seconds // 3600
            minutes = (seconds % 3600) // 60
            seconds = seconds % 60
            time_left = []
            if hours > 0: time_left.append(f"{hours}h")
            if minutes > 0: time_left.append(f"{minutes}m")
            if seconds > 0: time_left.append(f"{seconds}s")
            await ctx.send(f"⏳ {ctx.author.mention}, you can mine again in **{' '.join(time_left)}**.")

    @cut.error
    async def cut_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            seconds = int(error.retry_after)
            hours = seconds // 3600
            minutes = (seconds % 3600) // 60
            seconds = seconds % 60
            time_left = []
            if hours > 0: time_left.append(f"{hours}h")
            if minutes > 0: time_left.append(f"{minutes}m")
            if seconds > 0: time_left.append(f"{seconds}s")
            await ctx.send(f"⏳ {ctx.author.mention}, you can cut again in **{' '.join(time_left)}**.")

    @farm.error
    async def farm_error(self, ctx, error):
        if isinstance(error, commands.CommandOnCooldown):
            seconds = int(error.retry_after)
            hours = seconds // 3600
            minutes = (seconds % 3600) // 60
            seconds = seconds % 60
            time_left = []
            if hours > 0: time_left.append(f"{hours}h")
            if minutes > 0: time_left.append(f"{minutes}m")
            if seconds > 0: time_left.append(f"{seconds}s")
            await ctx.send(f"⏳ {ctx.author.mention}, you can farm again in **{' '.join(time_left)}**.")



async def setup(bot):
    await bot.add_cog(Economy(bot))
