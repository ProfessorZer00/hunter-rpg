import pytest
import asyncio
from utils import inventory_utils as inv
from config import DATABASE_PATH
import aiosqlite

@pytest.mark.asyncio
async def test_add_and_remove_item(tmp_path):
    db_path = tmp_path / "test.db"
    
    # Setup table
    async with aiosqlite.connect(db_path) as db:
        await db.execute("CREATE TABLE inventory (user_id INTEGER, item_name TEXT, quantity INTEGER, PRIMARY KEY(user_id, item_name))")
        await db.commit()
    
    # Monkeypatch DATABASE_PATH
    inv.DATABASE_PATH = str(db_path)
    
    await inv.add_item(1, "Sword", 2)
    await inv.remove_item(1, "Sword", 1)

    async with aiosqlite.connect(db_path) as db:
        cursor = await db.execute("SELECT quantity FROM inventory WHERE user_id = 1 AND item_name = 'Sword'")
        row = await cursor.fetchone()
        assert row[0] == 1
