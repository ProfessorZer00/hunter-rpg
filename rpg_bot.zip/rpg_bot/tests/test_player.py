import pytest
import asyncio
import aiosqlite
from config import DATABASE_PATH

@pytest.mark.asyncio
async def test_player_registration(tmp_path):
    db_path = tmp_path / "test.db"
    async with aiosqlite.connect(db_path) as db:
        await db.execute("""
            CREATE TABLE players (
                user_id INTEGER PRIMARY KEY, 
                name TEXT, class TEXT, level INTEGER, xp INTEGER,
                hp INTEGER, attack INTEGER, defense INTEGER,
                gold INTEGER, gems INTEGER
            )
        """)
        await db.commit()
    
    # Register player
    async with aiosqlite.connect(db_path) as db:
        await db.execute("INSERT INTO players (user_id, name, class, level, xp, hp, attack, defense, gold, gems) VALUES (1,'Test','Assassin',1,0,50,4,4,100,5)")
        await db.commit()
    
    async with aiosqlite.connect(db_path) as db:
        cursor = await db.execute("SELECT * FROM players WHERE user_id=1")
        player = await cursor.fetchone()
        assert player[1] == "Test"
