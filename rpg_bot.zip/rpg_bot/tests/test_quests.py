import pytest
import asyncio
import aiosqlite

@pytest.mark.asyncio
async def test_quest_progress(tmp_path):
    db_path = tmp_path / "test.db"
    
    async with aiosqlite.connect(db_path) as db:
        await db.execute("""
            CREATE TABLE quests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                quest_name TEXT,
                progress INTEGER,
                goal INTEGER,
                reward_xp INTEGER,
                reward_gold INTEGER,
                reward_item TEXT,
                completed INTEGER
            )
        """)
        await db.commit()

        # Add quest
        await db.execute("INSERT INTO quests (user_id, quest_name, progress, goal, reward_xp, reward_gold, reward_item, completed) VALUES (1,'Test Quest',0,5,50,20,NULL,0)")
        await db.commit()

        # Update progress
        await db.execute("UPDATE quests SET progress = progress + 3 WHERE user_id=1")
        await db.commit()

        cursor = await db.execute("SELECT progress FROM quests WHERE user_id=1")
        progress = await cursor.fetchone()
        assert progress[0] == 3
