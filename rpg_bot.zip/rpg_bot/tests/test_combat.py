import pytest
from utils.combat_utils import calculate_damage, calculate_xp_for_kill

def test_calculate_damage_minimum():
    assert calculate_damage(5, 10) >= 1  # damage never below 1

def test_calculate_damage_normal():
    dmg = calculate_damage(10, 5)
    assert 3 <= dmg <= 7  # accounts for random variation

def test_xp_for_kill():
    xp = calculate_xp_for_kill(5)
    assert xp == 20 + 5*5
