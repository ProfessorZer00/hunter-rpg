import discord

# --- Bot Settings ---
BOT_PREFIX = "!"
INTENTS = discord.Intents.default()
INTENTS.message_content = True   # Needed for reading message content
INTENTS.members = True           # Needed for member joins, PvP, etc.

# --- Extensions (Cogs) ---
EXTENSIONS = [
    "cogs.player",
    "cogs.combat",
    "cogs.inventory",
    "cogs.quests",
    "cogs.crafting",
    "cogs.pets",
    "cogs.market",
    "cogs.economy",
    "cogs.pvp",
    "cogs.raid",
    "cogs.admin",
    "cogs.events",
]

# --- Database ---
DATABASE_PATH = "database/rpg.db"

# --- Economy ---
STARTING_GOLD = 100
STARTING_GEMS = 10

# --- Player Defaults ---
DEFAULT_HP = 30
DEFAULT_ATTACK = 6
DEFAULT_DEFENSE = 4
DEFAULT_CLASS = "Adventurer"
