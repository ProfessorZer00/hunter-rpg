import os
import asyncio
from discord.ext import commands
from config import BOT_PREFIX, INTENTS, EXTENSIONS
from dotenv import load_dotenv
from database.db_manager import migrate
from keep_alive import keep_alive

keep_alive()

# Load token from .env
load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")

# Initialize bot
bot = commands.Bot(command_prefix=BOT_PREFIX, intents=INTENTS)


@bot.event
async def on_ready():
    print(f"✅ Logged in as {bot.user} (ID: {bot.user.id})")
    print("------")
    # Sync application commands (slash commands if added later)
    try:
        synced = await bot.tree.sync()
        print(f"🔗 Synced {len(synced)} command(s)")
    except Exception as e:
        print(f"❌ Failed to sync commands: {e}")


async def load_extensions():
    """Load all cogs listed in config.py"""
    for ext in EXTENSIONS:
        try:
            await bot.load_extension(ext)
            print(f"✅ Loaded extension: {ext}")
        except Exception as e:
            print(f"❌ Failed to load {ext}: {e}")


async def main():
    async with bot:
        await load_extensions()
        await migrate()
        await bot.start(TOKEN)


if __name__ == "__main__":
    asyncio.run(main())
