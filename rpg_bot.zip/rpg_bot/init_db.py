import aiosqlite, asyncio
from config import DATABASE_PATH

async def init_db():
    async with aiosqlite.connect(DATABASE_PATH) as db:
        with open("database/schema.sql") as f:
            await db.executescript(f.read())
        await db.commit()

asyncio.run(init_db())
