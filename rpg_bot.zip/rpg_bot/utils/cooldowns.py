import time

cooldowns = {}

def check_cooldown(user_id, action, duration):
    """Returns True if user is off cooldown."""
    key = f"{user_id}:{action}"
    last_used = cooldowns.get(key, 0)
    now = time.time()
    if now - last_used >= duration:
        cooldowns[key] = now
        return True
    return False
