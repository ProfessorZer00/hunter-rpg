import aiosqlite
from config import DATABASE_PATH

async def add_item(user_id: int, item_name: str, quantity: int = 1):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        await db.execute(
            "INSERT INTO inventory (user_id, item_name, quantity) VALUES (?, ?, ?) "
            "ON CONFLICT(user_id, item_name) DO UPDATE SET quantity = quantity + ?",
            (user_id, item_name, quantity, quantity),
        )
        await db.commit()

async def remove_item(user_id: int, item_name: str, quantity: int = 1):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        cursor = await db.execute(
            "SELECT quantity FROM inventory WHERE user_id = ? AND item_name = ?", (user_id, item_name)
        )
        row = await cursor.fetchone()
        if row and row[0] >= quantity:
            new_qty = row[0] - quantity
            if new_qty <= 0:
                await db.execute("DELETE FROM inventory WHERE user_id = ? AND item_name = ?", (user_id, item_name))
            else:
                await db.execute(
                    "UPDATE inventory SET quantity = ? WHERE user_id = ? AND item_name = ?", (new_qty, user_id, item_name)
                )
            await db.commit()
            return True
        return False
