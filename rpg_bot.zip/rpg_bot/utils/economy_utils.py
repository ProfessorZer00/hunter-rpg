import aiosqlite
from config import DATABASE_PATH

async def add_gold(user_id: int, amount: int):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        await db.execute("UPDATE players SET gold = gold + ? WHERE user_id = ?", (amount, user_id))
        await db.commit()

async def add_gems(user_id: int, amount: int):
    async with aiosqlite.connect(DATABASE_PATH) as db:
        await db.execute("UPDATE players SET gems = gems + ? WHERE user_id = ?", (amount, user_id))
        await db.commit()
