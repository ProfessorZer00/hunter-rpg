import random

def calculate_damage(attacker_attack, defender_defense):
    """Calculate damage dealt in combat."""
    damage = attacker_attack - defender_defense + random.randint(-1, 1)
    return max(1, damage)  # minimum 1 damage

def calculate_xp_for_kill(monster_level):
    """XP gained from killing a monster."""
    return 20 + monster_level * 5
