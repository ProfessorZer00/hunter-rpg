import discord

def create_profile_embed(user_name, player_class, level, xp, hp, attack, defense, gold, gems):
    embed = discord.Embed(title=f"{user_name}'s Profile", color=discord.Color.blue())
    embed.add_field(name="Class", value=player_class)
    embed.add_field(name="Level", value=level)
    embed.add_field(name="XP", value=xp)
    embed.add_field(name="HP", value=hp)
    embed.add_field(name="Attack", value=attack)
    embed.add_field(name="Defense", value=defense)
    embed.add_field(name="Gold", value=gold)
    embed.add_field(name="Gems", value=gems)
    return embed
